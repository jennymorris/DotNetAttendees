﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PivotalWorkshop.Utilities;

namespace PivotalWorkshop.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            //string connection = PCFEnvironment.DbConnectionString;
            //Console.WriteLine("\n\ncall attendeecontext connection string"+ System.Configuration.ConfigurationManager.ConnectionStrings["AttendeeContext"].ConnectionString);
            //Console.WriteLine("\n\ncall pcfenv.dbconnectionstring"+ PCFEnvironment.DbConnectionString);

            ViewBag.IpAddress = WebHelper.ServerIPAddress;

           

            // ViewBag.CFConnString = PCFEnvironment.DbConnectionString;
            //ViewBag.LocalConnString = System.Configuration.ConfigurationManager.ConnectionStrings["AttendeeContext"].ConnectionString;

            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";
            ViewBag.IpAddress = WebHelper.ServerIPAddress;
            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";
            ViewBag.IpAddress = WebHelper.ServerIPAddress;
            return View();
        }

        public void KillMe()
        {
            WebHelper.KillTheApp();
        }
    }
}