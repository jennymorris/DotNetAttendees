﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace PivotalWorkshop.DAL
{
    public class DatabaseInitializer: CreateDatabaseIfNotExists<AttendeeContext>
    {
 
        protected override void Seed(AttendeeContext databaseContext)
        {
          
            databaseContext.SaveChanges();
        }
    }
}