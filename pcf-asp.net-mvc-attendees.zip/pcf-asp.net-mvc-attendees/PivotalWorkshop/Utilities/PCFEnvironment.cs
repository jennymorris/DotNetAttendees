﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using Newtonsoft.Json.Linq;
using MySql.Data.MySqlClient;

namespace PivotalWorkshop.Utilities
{
    public class PCFEnvironment
    {
        private static readonly string INSTANCE_GUID_ENV_VARIABLE_NAME = "INSTANCE_GUID";
        private static readonly string BOUND_SERVICES_ENV_VARIABLE_NAME = "VCAP_SERVICES";
        private static readonly string PORT_ENV_VARIABLE_NAME = "PORT";
        private static readonly string INSTANCE_INDEX_ENV_VARIABLE_NAME = "INSTANCE_INDEX";

        private static string _connectionString = string.Empty;

        static PCFEnvironment()
        {
            if (BoundServices.GetValue("p-mysql") != null)
            {
                MySqlConnectionStringBuilder csbuilder = new MySqlConnectionStringBuilder();

                csbuilder.Add("server", BoundServices["p-mysql"][0]["credentials"]["hostname"].ToString());
                csbuilder.Add("port", BoundServices["p-mysql"][0]["credentials"]["port"].ToString());
                csbuilder.Add("uid", BoundServices["p-mysql"][0]["credentials"]["username"].ToString());
                csbuilder.Add("pwd", BoundServices["p-mysql"][0]["credentials"]["password"].ToString());
                csbuilder.Add("database", BoundServices["p-mysql"][0]["credentials"]["name"].ToString());

                //csbuilder.Add("server", BoundServices["p.mysql"][0]["credentials"]["hostname"].ToString());
                //csbuilder.Add("port", BoundServices["p.mysql"][0]["credentials"]["port"].ToString());
                //csbuilder.Add("uid", BoundServices["p.mysql"][0]["credentials"]["username"].ToString());
                //csbuilder.Add("pwd", BoundServices["p.mysql"][0]["credentials"]["password"].ToString());
                //csbuilder.Add("database", BoundServices["p.mysql"][0]["credentials"]["name"].ToString());

                _connectionString = csbuilder.ToString();
                Console.WriteLine("pcfenvConnectionString" + _connectionString);
            }

            if (BoundServices.GetValue("mssql-dev") != null) // sql server
            {
                DbEngine = DatabaseEngine.SqlServer;
            }
            else if (BoundServices.GetValue("p-mysql") != null)
            {
                DbEngine = DatabaseEngine.MySql; ;
            }
            else
            {
                DbEngine = DatabaseEngine.None;
            }
                
        }

        public static JObject BoundServices
        {
            get
            {
                Console.WriteLine("Calling BoundServices");
                return JObject.Parse(Environment.GetEnvironmentVariable(BOUND_SERVICES_ENV_VARIABLE_NAME));
            }
        }

        public static string DbConnectionString
        {
            get
            {
                Console.WriteLine("DbConnectionString");
                return _connectionString;
            }
        }

        public static string Port
        {
            get { return Environment.GetEnvironmentVariable(PORT_ENV_VARIABLE_NAME); }
        }

        public static string InstanceID
        {
            get { return Environment.GetEnvironmentVariable(INSTANCE_GUID_ENV_VARIABLE_NAME); }
        }

        public static string InstanceIndex
        {
            get { return Environment.GetEnvironmentVariable(INSTANCE_INDEX_ENV_VARIABLE_NAME); }
        }

        public static string Uptime
        {
            get { return DateTime.Now.Subtract(TimeSpan.FromMilliseconds(Environment.TickCount)).ToString(); }
        }

        public static DatabaseEngine DbEngine
        {
            get;
            set;
        }

    }

    public enum DatabaseEngine
    {
        None = 0,
        SqlServer = 1,
        MySql = 2
    }
}